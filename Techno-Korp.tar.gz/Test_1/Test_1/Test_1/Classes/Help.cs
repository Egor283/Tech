using Avalonia.Controls;
using Test_1.Models;

namespace Test_1.Classes;

public static class Help
{
    public static ContentControl HCC;
    public static TestContext TC = new TestContext();
}