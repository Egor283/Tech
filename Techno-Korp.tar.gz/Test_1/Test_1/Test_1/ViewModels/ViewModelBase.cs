﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Test_1.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}