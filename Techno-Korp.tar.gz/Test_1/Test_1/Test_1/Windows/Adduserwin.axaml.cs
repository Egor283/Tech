using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Microsoft.EntityFrameworkCore;
using Test_1.Classes;
using Test_1.Models;

namespace Test_1.Windows;

public partial class Adduserwin : Window
{
    
    private int _id;
    public Adduserwin(int id = -1)
    {
        InitializeComponent();
        Help.TC.Employees.Load();
        Help.TC.Positions.Load();
        Help.TC.Departments.Load();
        DolTB.ItemsSource = Help.TC.Positions.Select(el => el.Id).ToList();
        PodTB.ItemsSource = Help.TC.Departments.Select(el => el.Id).ToList();
        RukTB.ItemsSource = Help.TC.Employees.Select(el => el.Id).ToList();
        _id = id;
        if (_id == -1)
        {
            SP.DataContext = new Employee();
            IDTB.Text = (Help.TC.Employees.Count() + 1).ToString();
        }
        else
        {
            var user = Help.TC.Employees.FirstOrDefault(el => el.Id == _id);
            IDTB.Text = user.Id.ToString();
            SP.DataContext = user;
        }
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_id == -1)
        {
            Help.TC.Employees.Add(SP.DataContext as Employee);
        }
        Help.TC.SaveChanges();
        Close();
    }

    private void OtmBTn_OnClick(object? sender, RoutedEventArgs e)
    {
        Close();
    }
}