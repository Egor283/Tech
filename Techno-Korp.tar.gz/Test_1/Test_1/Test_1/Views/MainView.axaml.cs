using System.Linq;
using System.Net.Mime;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;
using Test_1.Classes;
using Test_1.Models;
using Test_1.Windows;

namespace Test_1.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        LoadData();
    }

    private void LoadData()
    {
        Help.TC.Employees.Load();
        DG.ItemsSource = Help.TC.Employees.ToList();
    }

    private void EditBtn_OnClick(object? sender, RoutedEventArgs e)
    {
     var us = DG.SelectedItem as Employee;
     if (us == null)
     {
         MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали пользователя").ShowAsync();
         return;
     }
     Window winn = new Adduserwin(us.Id);
     winn.Show();
     LoadData();
    }

    private void DelBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var us = DG.SelectedItem as Employee;
        if (us == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали пользователя").ShowAsync();
            return;
        }

        if (us.DismissalDate == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Пользователь не уволен").ShowAsync();
            return;
        }
        Help.TC.Employees.Remove(us);
        Help.TC.SaveChanges();
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Window winn = new Adduserwin();
        winn.Show();
    }

    private void ObBTN_OnClick(object? sender, RoutedEventArgs e)
    {
        LoadData();
    }

    private void ActiveBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        DG.ItemsSource = Help.TC.Employees.Where(el => el.DismissalDate == null).ToList();
    }

    private void NoActiveBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        DG.ItemsSource = Help.TC.Employees.Where(el => el.DismissalDate != null).ToList();
    }

    private void FindTB_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        DG.ItemsSource = Help.TC.Employees.Where(el => el.Name.Contains(FindTB.Text) || el.FirstName.Contains(FindTB.Text) ||
                                                       el.LastName.Contains(FindTB.Text) || 
                                                       Help.TC.Positions.First(el1 => el1.Id.ToString() == 
                                                           el.PositionId).Title.Contains(FindTB.Text)).ToList();
    }
}