using Avalonia.Controls;
using Avalonia.Interactivity;
using Test_1.Classes;

namespace Test_1.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.HCC = this;
        Help.HCC = CCW;
        CCW.Content = new MainView();
    }

    private void NazBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.HCC = new MainView();
    }
}