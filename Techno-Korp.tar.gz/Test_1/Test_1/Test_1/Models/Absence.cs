﻿using System;
using System.Collections.Generic;

namespace Test_1.Models;

public partial class Absence
{
    public int Id { get; set; }

    public string? TypeId { get; set; }

    public DateTime? StartDate { get; set; }

    public string? EndDate { get; set; }

    public string? EmployeeId { get; set; }
}
