﻿using System;
using System.Collections.Generic;

namespace Test_1.Models;

public partial class Employee
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Phone { get; set; }

    public DateTime? Birthday { get; set; }

    public string? PositionId { get; set; }

    public string? DepartmentId { get; set; }

    public string? ManagerId { get; set; }

    public DateTime? DismissalDate { get; set; }
}
