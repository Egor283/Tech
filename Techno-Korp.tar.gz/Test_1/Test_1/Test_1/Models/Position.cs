﻿using System;
using System.Collections.Generic;

namespace Test_1.Models;

public partial class Position
{
    public int Id { get; set; }

    public string Title { get; set; } = null!;
}
