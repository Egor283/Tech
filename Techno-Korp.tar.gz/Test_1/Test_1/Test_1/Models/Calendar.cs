﻿using System;
using System.Collections.Generic;

namespace Test_1.Models;

public partial class Calendar
{
    public DateTime Date { get; set; }

    public sbyte? IsWorkingDay { get; set; }
}
