﻿using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Gostinica_Laguna.Classes;
using Gostinica_Laguna.Models;

namespace Gostinica_Laguna.Windows;

public partial class AddUserWindow : Window
{
    private Guest _guest = new Guest();
    private int _id;
    public AddUserWindow(int id=-1)
    {
        InitializeComponent();
        _id = id;
        if (_id == -1)
        {
            IDTB.Text = (Help.WC.Guests.Count() + 1).ToString();
            SP.DataContext = new Guest();
        }
        else
        {
            IDTB.Text = Help.WC.Guests.Where(el => el.Id == _id).ToString();
            var _guest = Help.WC.Guests.FirstOrDefault(el => el.Id == _id);
            SP.DataContext = _guest;
        }
    }

    private void NazBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Close();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_id == -1)
        {
            Help.WC.Guests.Add(SP.DataContext as Guest);
        }
        Help.WC.SaveChanges();
        Close();
    }
}