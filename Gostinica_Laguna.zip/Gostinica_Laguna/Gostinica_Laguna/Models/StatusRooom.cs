﻿using System;
using System.Collections.Generic;

namespace Gostinica_Laguna.Models;

public partial class StatusRooom
{
    public int Id { get; set; }

    public string? Type { get; set; }
}
