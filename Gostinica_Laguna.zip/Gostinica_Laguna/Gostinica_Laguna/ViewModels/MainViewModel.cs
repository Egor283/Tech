﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Gostinica_Laguna.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    [ObservableProperty] private string _greeting = "Welcome to Avalonia!";
}