﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Gostinica_Laguna.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}