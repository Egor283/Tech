using Avalonia.Controls;
using Gostinica_Laguna.Classes;

namespace Gostinica_Laguna.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.CCH = this;
        Help.CCH = CCW;
        CCW.Content = new MainView();
    }
}