using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Gostinica_Laguna.Classes;
using Gostinica_Laguna.Models;
using Gostinica_Laguna.Windows;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace Gostinica_Laguna.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        LoadData();
    }

    private void LoadData()
    {
        Help.WC.Guests.Load();
        DG.ItemsSource = Help.WC.Guests.ToList();
    }

    private void EditBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var guest = DG.SelectedItem as Guest;
        if (guest == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали гостя").ShowAsync();
            return;
        }
        Window win = new AddUserWindow(guest.Id);
        win.Show();
    }

    private void DelBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var us = DG.SelectedItem as Guest;
        if (us == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали гостя").ShowAsync();
            return;
        }

        Help.WC.Guests.Remove(us);
        Help.WC.SaveChanges();
    }

    private void FindTB_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        DG.ItemsSource = Help.WC.Guests.Where(el => el.Name.Contains(FindTB.Text) ||
                                                    el.FirstName.Contains(FindTB.Text) ||
                                                    el.LastName.Contains(FindTB.Text)).ToList();
    }

    private void ObBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        LoadData();
    }

    private void DobBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Window win = new AddUserWindow();
        win.Show();
    }
}