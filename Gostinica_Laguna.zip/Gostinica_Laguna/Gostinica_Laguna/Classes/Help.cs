﻿using Avalonia.Controls;
using Gostinica_Laguna.Models;

namespace Gostinica_Laguna.Classes;

public static class Help
{
    public static ContentControl CCH;
    public static WorldContext WC = new WorldContext();
}